id,password,role,createdAt,updatedAt,username
9,$2a$10$rKCrRkt/gS7ze9kkdR3MHey.a6lYhWx1ELOyKup/StPcvQ9TI1FV6,customer,2024-05-01 22:54:56.331+05:30,2024-05-01 22:54:56.331+05:30,ragu
10,$2a$10$waH4zEMMT7hpP4NRDPKWqOd2XHBNLbatv11tnX./kZIX6BhXW7YOq,admin,2024-05-01 23:43:05.784+05:30,2024-05-01 23:43:05.784+05:30,ragubathi
