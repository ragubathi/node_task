id,name,description,price,stock,createdAt,updatedAt,category_id
1,Product 1,Description of product 1,10,In stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,1
2,Product 2,Description of product 2,20,Out of stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,2
3,Product 3,Description of product 3,30,In stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,3
4,Product 4,Description of product 4,40,Out of stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,1
5,Product 5,Description of product 5,50,In stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,2
6,Product 6,Description of product 6,60,Out of stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,3
7,Product 7,Description of product 7,70,In stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,1
8,Product 8,Description of product 8,80,Out of stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,2
9,Product 9,Description of product 9,90,In stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,3
10,Product 10,Description of product 10,100,Out of stock,2024-05-01 23:34:06.053667+05:30,2024-05-01 23:34:06.053667+05:30,1
